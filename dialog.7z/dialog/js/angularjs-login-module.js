//create an application and controller to control the login tag and
'use strict'

var app=angular.module('loginApp', [
    'ngStorage',
    'ngRoute',
    'angular-loading-bar'
]);


app.config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {

    $httpProvider.interceptors.push(['$q', '$location', '$localStorage', function($q, $location, $localStorage) {
            return {
                'request': function (config) {
                    config.headers = config.headers || {};
                    if ($localStorage.token) {
                        config.headers.Authorization = 'Bearer ' + $localStorage.token;
                    }
                    return config;
                },
                'responseError': function(response) {
                    if(response.status === 401 || response.status === 403) {
                        $location.path('/signin');
                    }
                    return $q.reject(response);
                },
				'response':function(response){
			//		alert("response interceptor"+response.data);
					return response;
				}
            };
        }]);

    }
]);

app.controller("testCtrl",['$rootScope', '$scope', '$location', '$localStorage','$http', function($rootScope, $scope, $location, $localStorage,$http) {
  $scope.obj={};
  $scope.obj.mydata = "loaded";
  $scope.usersignin1 = function() {
      var formData = {
          userName: $scope.userName,
          password: $scope.password
      }
      alert("hello");

      var path="";


      $http.post("/footovision/private/php/centralRequestHandle.php",formData)
      .success(function(res) {
          if (res.type == false) {

          } else {
              $localStorage.token = res.jwt;
              $scope.data=res.data;
            //  $rootScope.loginUser=$scope.email;
              alert("login succes. then length of the data is "+$scope.data.length);
              //refresh the page
              window.close();
          }
      })
      .error(function() {
        alert("failed to load ");
                $rootScope.error = 'Failed to signin';
            });
   };

   $scope.userCancel=function(){
     alert("cancel was called");
   };
   alert("initial finished");

}]);

/*
app.controller("testCtrl",[ '$rootScope', '$scope','$location','$localStorage','$http',function($scope,$localStorage,$location,$rootScope,$http){
	$scope.obj={};
	$scope.obj.mydata="data from testCtrl";
	
  $scope.usersignin1 = function() {
      var formData = {
          userName: $scope.userName,
          password: $scope.password
      }
      alert("hello");

      var path="";


      $http.post("/footovision/private/php/centralRequestHandle.php",formData)
      .success(function(res) {
          if (res.type == false) {

          } else {
              $localStorage.token = res.jwt;
              $scope.data=res.data;
            //  $rootScope.loginUser=$scope.email;
              alert("login succes. then length of the data is "+$scope.data.length);
              //refresh the page
              window.close();
          }
      })
      .error(function() {
        alert("failed to load ");
                $rootScope.error = 'Failed to signin';
            });
   };

   $scope.userCancel=function(){
     alert("cancel was called");
   };
   alert("initial finished");
	
	
}]);
*/
/*
app.controller("testCtrl",['$http', '$scope', '$location', '$localStorage', function($rootScope, $scope, $location, $localStorage,$http){
	$scope.obj={};
	$scope.obj.mydata="data from testCtrl";
	
	$scope.usersignin1=function(){alert("alert");};
	
	
}]);*/